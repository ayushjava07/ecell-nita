NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.
----------------------------------------------------------------------------------------------------------------
For Commercial License you can download here :
https://fontbundles.net/embuntype/782714-think-typeface

Paypal account for donation : https://www.paypal.me/aditrezki

If you need an extended license or corporate license, please contact us at
embunstudio2018@gmail.com

Please visit our store for more great fonts : 
https://fontbundles.net/embuntype

And follow my instagram or update : @adityarezki12

or follow behance : https://www.behance.net/EmbunStudio

Thank you
Have A Nice day